#include <stdio.h>
#include <string.h>

int main() {
    int pilihan, totalHarga = 0; // Variabel untuk menyimpan pilihan pengguna dan total harga pesanan
    char pesanan[100][100]; // Array untuk menyimpan daftar pesanan
    int jumlahPesanan = 0; // Variabel untuk menghitung jumlah pesanan

    // Menu utama yang ditampilkan kepada pengguna
    char *menuUtama[] = {
        "Tampilkan Menu Makanan",
        "Tampilkan Menu Minuman",
        "Tampilkan Menu Hidangan Penutup",
        "Keluar"
    };
    int jumlahMenuUtama = 4; // Jumlah menu utama

    // Daftar menu makanan dengan harga
    char *menuMakanan[] = {
        "Nasi Goreng - Rp 20.000",
        "Mie Goreng - Rp 18.000",
        "Ayam Goreng - Rp 25.000",
        "Sate Ayam - Rp 30.000",
        "Bakso - Rp 15.000"
    };
    int hargaMakanan[] = {20000, 18000, 25000, 30000, 15000}; // Harga untuk masing-masing menu makanan
    int jumlahMenuMakanan = 5; // Jumlah menu makanan

    // Daftar menu minuman dengan harga
    char *menuMinuman[] = {
        "Teh Manis - Rp. 10.000",
        "Teh Tawar - Rp. 5.000",
        "Jus Jeruk - Rp. 12.000",
        "Teh Susu - Rp. 7.000",
        "Teh Hijau - Rp. 8.000"
    };
    int hargaMinuman[] = {10000, 5000, 12000, 7000, 8000}; // Harga untuk masing-masing menu minuman
    int jumlahMenuMinuman = 5; // Jumlah menu minuman

    // Daftar menu hidangan penutup dengan harga
    char *menuHidanganPenutup[] = {
        "Es Krim - Rp 15.000",
        "Puding Coklat - Rp 12.000",
        "Kue Brownies - Rp 20.000"
    };
    int hargaHidanganPenutup[] = {15000, 12000, 20000}; // Harga untuk masing-masing menu hidangan penutup
    int jumlahMenuHidanganPenutup = 3; // Jumlah menu hidangan penutup

    printf("=== Selamat Datang ===\n");

    // Loop utama untuk menampilkan menu dan menerima pilihan pengguna
    while (1) {
        printf("\n=== Menu Utama ===\n");
        for (int i = 0; i < jumlahMenuUtama; i++) {
            printf("%d. %s\n", i + 1, menuUtama[i]); // Menampilkan menu utama
        }
        printf("====================\n");
        printf("Pilih opsi (1-%d): ", jumlahMenuUtama); // Meminta pengguna memilih menu utama
        scanf("%d", &pilihan);

        // Proses berdasarkan pilihan menu utama
        if (pilihan == 1) { // Menampilkan menu makanan
            printf("\n=== Menu Makanan ===\n");
            for (int i = 0; i < jumlahMenuMakanan; i++) {
                printf("%d. %s\n", i + 1, menuMakanan[i]); // Menampilkan menu makanan
            }
            printf("====================\n");

            printf("Pilih nomor menu yang ingin dipesan (0 untuk kembali): ");
            scanf("%d", &pilihan);

            if (pilihan == 0) { // Kembali ke menu utama
                continue;
            } else if (pilihan >= 1 && pilihan <= jumlahMenuMakanan) { // Pilihan menu makanan yang valid
                printf("Anda memesan: %s\n", menuMakanan[pilihan - 1]);
                printf("Harga: Rp %d\n", hargaMakanan[pilihan - 1]);
                totalHarga += hargaMakanan[pilihan - 1]; // Menambahkan harga ke total
                strcpy(pesanan[jumlahPesanan++], menuMakanan[pilihan - 1]); // Menyimpan pesanan
            } else {
                printf("Pilihan tidak valid. Silakan coba lagi.\n");
            }
        } else if (pilihan == 2) { // Menampilkan menu minuman
            printf("\n=== Menu Minuman ===\n");
            for (int i = 0; i < jumlahMenuMinuman; i++) {
                printf("%d. %s\n", i + 1, menuMinuman[i]); // Menampilkan menu minuman
            }
            printf("====================\n");

            printf("Pilih nomor menu yang ingin dipesan (0 untuk kembali): ");
            scanf("%d", &pilihan);

            if (pilihan == 0) { // Kembali ke menu utama
                continue;
            } else if (pilihan >= 1 && pilihan <= jumlahMenuMinuman) { // Pilihan menu minuman yang valid
                printf("Anda memesan: %s\n", menuMinuman[pilihan - 1]);
                printf("Harga: Rp %d\n", hargaMinuman[pilihan - 1]);
                totalHarga += hargaMinuman[pilihan - 1]; // Menambahkan harga ke total
                strcpy(pesanan[jumlahPesanan++], menuMinuman[pilihan - 1]); // Menyimpan pesanan
            } else {
                printf("Pilihan tidak valid. Silakan coba lagi.\n");
            }
        } else if (pilihan == 3) { // Menampilkan menu hidangan penutup
            printf("\n=== Menu Hidangan Penutup ===\n");
            for (int i = 0; i < jumlahMenuHidanganPenutup; i++) {
                printf("%d. %s\n", i + 1, menuHidanganPenutup[i]); // Menampilkan menu hidangan penutup
            }
            printf("====================\n");

            printf("Pilih nomor menu yang ingin dipesan (0 untuk kembali): ");
            scanf("%d", &pilihan);

            if (pilihan == 0) { // Kembali ke menu utama
                continue;
            } else if (pilihan >= 1 && pilihan <= jumlahMenuHidanganPenutup) { // Pilihan menu hidangan penutup yang valid
                printf("Anda memesan: %s\n", menuHidanganPenutup[pilihan - 1]);
                printf("Harga: Rp %d\n", hargaHidanganPenutup[pilihan - 1]);
                totalHarga += hargaHidanganPenutup[pilihan - 1]; // Menambahkan harga ke total
                strcpy(pesanan[jumlahPesanan++], menuHidanganPenutup[pilihan - 1]); // Menyimpan pesanan
            } else {
                printf("Pilihan tidak valid. Silakan coba lagi.\n");
            }
        } else if (pilihan == 4) { // Menampilkan daftar pesanan dan total harga
            printf("\n=== Daftar Pesanan Anda ===\n");
            for (int i = 0; i < jumlahPesanan; i++) {
                printf("%d. %s\n", i + 1, pesanan[i]); // Menampilkan daftar pesanan
            }
            printf("=========================\n");
            printf("Total harga pesanan Anda: Rp %d\n", totalHarga); // Menampilkan total harga

            // Memilih metode pembayaran
            printf("Pilih metode pembayaran:\n");
            printf("1. Bayar Sekarang\n");
            printf("2. Gunakan PayLater\n");
            printf("Pilihan Anda: ");
            scanf("%d", &pilihan);

            if (pilihan == 1) {
                printf("Terima kasih telah membayar. Pesanan Anda akan segera diproses!\n");
            } else if (pilihan == 2) {
                printf("Anda memilih PayLater. Silakan lunasi tagihan Anda nanti.\n");
            } else {
                printf("Pilihan tidak valid. Sistem menganggap Anda memilih PayLater.\n");
            }

            printf("Masakan sedang dimasak...\n");
            printf("Masakan selesai dimasak dan siap disajikan!\n");
            break; // Keluar dari program setelah proses selesai
        } else {
            printf("Pilihan tidak valid. Silakan coba lagi.\n"); // Jika pilihan menu utama tidak valid
        }
    }

    return 0;
}
